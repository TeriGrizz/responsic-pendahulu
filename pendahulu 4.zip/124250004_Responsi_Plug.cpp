#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

struct pasien{
	int idPasien;
	char nama[100];
	int statusPanggil;
	};
	
	struct NodeTree{
		pasien info;
		NodeTree *kiri;
		NodeTree *kanan;
		};
NodeTree *akar = NULL;

struct InfoUndo{
	int tipe; 
	int idPasien;
	int idAntrian;
	};
	
	struct NodeStack{
		InfoUndo info;
		NodeStack *Next;
		};
		NodeStack *awalstack = NULL;

struct NodeQueue{
	int idPasien;
	NodeQueue *next;
	};
	NodeQueue *depan = NULL;
	NodeQueue *belakang = NULL;
	
	NodeTree *p = akar;
	while (p != NULL){
		if(idPasien == p -> info.idPasien) return p;
		else if (idPasien < p -> info.idPasien) p = p -> kiri;
		else p = p -> kanan;
		}{
		return NULL;
	}
	bool stackKosong(){
		return(awalstack == NULL);
		}
		
		void pushStack(int tipe, int idPasien,int idAntrian = -1)
		{
			NodeStack *baru = new NodeStack;
			baru->info.tipe = tipe;
			baru->info.idPasien = idPasien;
			baru->info.idAntrian = idAntrian;
			baru -> next = awalStack;
			awalStack = baru;
			}
			
			infoUndo popStack(){
				infoUndo data = {-1,-1,-1};
				if (! stackKosong()){
					NodeStack *hapus= awalStack;
					data = hapus.info;
					awalStack = awalStack->next;
					delete hapus;
				}
				return data;
			}
			
			bool queueKosong(){
				return (depan ==NULL);
				}
				void enqueue (int idPasien){
					NodeQueue *baru = new NodeQueue;
					baru->idPasien = idPasien;
					baru->next = NULL;
					
					if(queueKosong()) depan =baru;
					else belakang->next =baru;
					
					belakang =baru;
					}
					
					int dequeue(){
						if(queueKosong()) return -1;
						NodeQueue *hapus =depan;
						int idPasien =hapus->idPasien;
						depan = depan->next;
						
						if (ddepan == NULL)belakang = NULL;
						delete hapus;
						return idPasien;
						}
						
						void hapusFromQueue(int idPasien){
							NodeQueue *curr = depan;
							NodeQueue *prev = NULL;
							
							while (curr != NULL){
								if(curr->idPasien == idPasien){
									if (prev == NULL)depan = curr->next:
									else prev -> next = curr -> next;
									
									if (curr == belakang) belakang = prev;
									
									delete curr;
									return;
								}
								prev = curr;
								curr = curr->next;
							}
						}
						
						bool sudahDiAntrian (int idPasien){\
							NodeQueue *cek =depan;
							while (cek == NULL){
								if(cek->idPasien ==idPasien) return true;
								cek = cek->next;
								} 
							return false;
							}
							
							void tambahData(){
								pasien data;
								cout << "\n Masukkan ID pasien : "; cin >> data.idPasien;
								cin >> ignore();
								cout << "Masukkan nama pasien: ";
								cin >> getline(data.nama,100);
								 
								data.statusPanggil = 1;
								
								NodeTree *baru = new NodeTree;
								baru->info =data;
								baru->kiri =NULL;
								baru->kanan =NULL;
								
								if (akar == NULL){
									akar = baru;
									cout << "Data pasien berhasil ditambahkan\n"
								}else{
									NodeTree *p =akar;
									NodeTree *b =NULL;
									
									while (p != NULL){
										b=p;
										if(data.idPasien < p->info.idPasien)p = p->kiri;
										else if (data.idPasien > p->info.idPasien)p = p->kanan;
										else {
											cout << "ID pasien sudah terdaftar\n";
											delete baru;
											return;
										}
									}
									
									if (data.idPasien < b-> info.idPasien)b->kiri =baru;
									else b-> kanan = baru;
									cout << "data berhasil ditambahkan\n";
								}
							}
							
							void cetakInOrder (NodeTree *node){
								if (node != NULL){
									cetakInOrder(node->kiri);
									cout << "----------\n";
									cout << "ID pasien: \n";
									cout << "Nama : \n";
									cout << "\nStatus: ";
									
									void tampilData (){
										cout << "=== Data Pasien ===";
										if(akar == NULL) cout << "belum ada data.\n";
										else cetakInOrder(akar);
								}
							}
						}
						
						void panggilPasien(){
							int idPasien;
							cout << "\n Masukkan ID pasien : "; cin >> idPasien;
							
							NodeTree *k = cariPasien(idPasien);
							if (k == NULL){
								cout << "karyawan tidak ketemmu!\n"
							}else{
								if(k->info.statusPanggil == 0){
									k->imfo.statusPanggil =1;
									pushStack(1, idPasien);
									cout << "pasien sedang di periksa\n";
								}else{
									if(sudahDiAntrian (idPasien){
										cout << "pasien sedang dalam antrian\n";
								}else{
									enqueue(idPasien){
										cout << "pasien masuk dalam antrian\n";
									}
								}
							}
						}
						
	void selesaiPeriksa() {
		int idPasien;
		cout << "\nMasukkan ID pasien yang telah di periksa: ";
		cin >> idPasien;
		
		NodeTree *k = cariPasien (idPasien);
		if (k == NULL){
			cout << "pasien tidak ketemu!\n";
		}else {
			if (k -> info.statusPanggil == 1){
				k -> info.statusPanggil == 0;
				cout << "Pemeriksaan pasien" cin >> nama; "telah selesai\n";
				
				int idPasienAntri = -1;
				if (queueKosong()){
					idAntrian = dequeue();
					NodeTree *kAntrian = cariPasien(idAntrian);
					if(kAntrian 1= NULL){
						kAntrian->info.statusPanggil = 1;
						cout << "pengajuan berikutnya langsung masuk antrian\n";
		}else{
			idAntrian = -1;
	}
}

pushStack(2,idPasien,idAntrian);
	}else{
		cout << "pasien tidak masuk antrian\n";
	}
}
}

void hapusPasien(){
	int idPasien;
	cout << "\n masukkan ID pasien : ";
	cin >> idPasien;
	
	NodeTree *p = akar;
	NodeTree *b = NULL;
	int ketemu = 0;
	
	while (p != NULL){
		if(idPasien == p->info.idPasien){ketemu = 1; break;}
		b = p;
		if (idPasien < p->info.idPasien) p= p-> kiri;
		else p = p->kanan;
	}
	if (ketemu == 0){
		cout << "pasien tidak ketemu\n";
		}
		int main(){
			do {
				cout << "\n1. tambah pasien";
				cout << "\n2. tampil data";
				cout << "\n3. panggil pasien";
				cout << "\n4. selesai periksa ";
				cout << "\n5. hapus pasien";
				cout << "pilih menu : " ; cin >> pilihan;
				
				switch (pilihan){
				case 1: tambahData();break;
				case 2: tampilData();break;
				case 3: panggilPasien();break;
				case 4: selesaiPeriksa();break;
				case 5: hapusPasien();break;
				
				
				
					
				}
			};
