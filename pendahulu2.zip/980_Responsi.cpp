#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <string>
using namespace std;

int jumlahData = 0;

struct stw {
	string namaHewan, keterangan, habitat;
	int populasi;
};

stw satwa[1000];

string replaceChar(string text, char source, char target) {
    string newtext = text;
    for(size_t i = 0; i < text.length(); i++) {
        if(text[i] == source)
            newtext[i] = target;   
    }
    return newtext;
}

string replaceSpacetoUnderscore(string text) {
    return replaceChar(text, ' ', '_');
}

string replaceUnderscoretoSpace(string text) {
    return replaceChar(text, '_', ' ');
}

string stringTolower(string text) {
    for(char& word : text) {
        word = (char)tolower(word);
    }
    return text;
}

string stringToupper(string text) {
    for(char& word : text) {
        word = (char)toupper(word);
    }
    return text;
}

void inputData () {
	string inputNamaHewan, inputHabitat;
	int inputPopulasi;
	cout << "====================" << endl;
	cout << "     INPUT DATA     " << endl;
	cout << "====================" << endl;
	cout << "Masukkan data hewan berikut ini" << endl;
	cin.ignore();
	cout << "Nama hewan = "; getline(cin, inputNamaHewan);
	cout << "Habitat    = "; getline(cin, inputHabitat);
	do {
		cout << "Populasi   = "; cin >> inputPopulasi;
		if (inputPopulasi < 0) {
			cout << "Input tidak valid!" << endl;
		}
	} while (inputPopulasi<0);
	satwa[jumlahData].namaHewan = replaceSpacetoUnderscore(inputNamaHewan);
	satwa[jumlahData].habitat = replaceSpacetoUnderscore(inputHabitat);
	satwa[jumlahData].populasi = inputPopulasi;
	if (inputPopulasi==0) {
		satwa[jumlahData].keterangan = "PUNAH";
	} else if (inputPopulasi>0 && inputPopulasi<100) {
		satwa[jumlahData].keterangan = "DILINDUNGI";
	} else if (inputPopulasi>=100 && inputPopulasi<1000) {
		satwa[jumlahData].keterangan = "LANGKA";
	} else if (inputPopulasi>=1000 && inputPopulasi<1000000) {
		satwa[jumlahData].keterangan = "TIDAK DILINDUNGI"; 
	} else if (inputPopulasi>=1000000) {
		satwa[jumlahData].keterangan = "MELIMPAH";
	}
	fstream file("data.txt", ios::app);
	file << satwa[jumlahData].namaHewan << " " 
		<< replaceSpacetoUnderscore(satwa[jumlahData].keterangan) << " " 
		<< satwa[jumlahData].populasi << " " 
		<< satwa[jumlahData].habitat << endl;
	file.close();
	jumlahData++;
}

void lihatData() {
	cout << "====================" << endl;
	cout << "     LIHAT DATA     " << endl;
	cout << "====================" << endl;
	cout << endl;
	cout << setfill('_') << setw(112) << "_" << endl;
	for (int i=0; i<jumlahData; i++) {
		cout << setfill(' ') << setw(30) << satwa[i].namaHewan << "  |";
		cout << setfill(' ') << setw(25) << satwa[i].keterangan << "  |";
		cout << setfill(' ') << setw(15) << satwa[i].populasi << "  |";
		cout << setfill(' ') << setw(30) << satwa[i].habitat << "  |";
		cout << endl;
	}
	cout << setfill('_') << setw(112) << "_" << endl;
}

void searchingData() {
	string cariNama;
	cout << "=====================" << endl;
	cout << "      SEARCHING      " << endl;
	cout << "=====================" << endl;
	cin.ignore();
	cout << "Nama hewan yang dicari = ";
	getline(cin, cariNama);
	string cari = stringToupper(cariNama);
	string target;
	bool found = false; 
	for (int i=0; i<jumlahData; i++){
		target = stringToupper(satwa[i].namaHewan);
		if (target==cari) {
			found = true;
			cout << "Data ditemukan!";
			cout << "Nama Hewan = "<< replaceUnderscoretoSpace(satwa[i].namaHewan) << endl;
			cout << "Habitat = " << replaceUnderscoretoSpace(satwa[i].habitat) << endl;
			cout << "Populasi = " << satwa[i].populasi << endl;
			cout << "Keterangan = " << replaceUnderscoretoSpace(satwa[i].keterangan)<< endl;
			break;
		}
	}
	if (!found) {
		cout << "Data tidak ditemukan!" << endl;
	}
}

void sortingData() {
	int pilihSort, pilihJenisSort;
	cout << "=====================" << endl;
	cout << "       SORTING       " << endl;
	cout << "=====================" << endl;
	cout << "\nSorting data berdasarkan : ";
	cout << "1. Nama" << endl;
	cout << "2. Keterangan" << endl;
	cout << "3. Populasi" << endl;
	cout << "Pilih => "; cin >> pilihSort;
	cout << "1. Ascending" << endl;
	cout << "2. Descending" << endl;
	cout << "Pilih => "; cin >> pilihJenisSort;
	if (pilihJenisSort==1) {
		for (int i=0; i<jumlahData-1; i++){
			for (int j=0; j<jumlahData-i-1; j++) {
				if (pilihSort==1) {
					if (satwa[j].namaHewan>satwa[j+1].namaHewan) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa [j+1] = temp; 
					}
				} else if (pilihSort==2) {
					if (satwa[j].keterangan>satwa[j+1].keterangan) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa[j+1] = temp;
					}
				} else if (pilihSort==3) {
					if (satwa[j].populasi>satwa[j+1].populasi) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa[j+1] = temp;
					}
				}
			}
		}
	} else if (pilihJenisSort==2) {
		for (int i=0; i<jumlahData-1; i++){
			for (int j=0; j<jumlahData-i-1; j++) {
				if (pilihSort==1) {
					if (satwa[j].namaHewan<satwa[j+1].namaHewan) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa [j+1] = temp; 
					}
				} else if (pilihSort==2) {
					if (satwa[j].keterangan<satwa[j+1].keterangan) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa[j+1] = temp;
					}
				} else if (pilihSort==3) {
					if (satwa[j].populasi<satwa[j+1].populasi) {
						stw temp = satwa[j];
						satwa[j] = satwa[j+1];
						satwa[j+1] = temp;
					}
				}
			}
		}
	}
}

void exitProgram() {
	cout << "~~~   THANK YOU   ~~~" << endl;
}

int main () {
	string temp1, temp2, temp4;
	int temp3;
	ifstream file("data.txt");
	while (file >> temp1 >> temp2 >> temp3 >> temp4) {
		satwa[jumlahData].namaHewan =  replaceUnderscoretoSpace(temp1);
		satwa[jumlahData].keterangan =  replaceUnderscoretoSpace(temp2);
		satwa[jumlahData].populasi = temp3;
		satwa[jumlahData].habitat =  replaceUnderscoretoSpace(temp4);
		jumlahData++;
	}
	file.close();
	
	int pilihMenu;
	char kembali;
	do {
		system("cls");
		cout << "==========================" << endl;
		cout << "        MENU UTAMA        " << endl;
		cout << "==========================" << endl;
		cout << "1. Input Data" << endl;
		cout << "2. Lihat Data" << endl;
		cout << "3. Searching Data" << endl;
		cout << "4. Sorting Data" << endl;
		cout << "0. Exit" << endl;
		cout << "Pilih menu => "; cin >> pilihMenu;
		
		system("cls");
		switch (pilihMenu) {
			case 1 : inputData();
				break;
			case 2 : lihatData();
				break;
			case 3 : searchingData();
				break;
			case 4 : sortingData();
				break;
			case 0 : exitProgram(); return 0;
				break;
			default : cout << "Menu tidak tersedia" <<endl;
				break;
		}
		if (pilihMenu != 0) {
			cout << "\nKembali ke menu? (Y/N) : "; cin >> kembali;
		}
	} while (kembali == 'Y' || kembali == 'y');
	
}
