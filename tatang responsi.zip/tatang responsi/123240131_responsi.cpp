#include <iostream>
#include <conio.h>
using namespace std;

void login(bool &berhasil, bool &ulang);
void daftar();
void transaksi();
void riwayat();
void riwayatNama();

int banyak_pesanan = 0;
int banyak_user = 0;
string nama[100];
string namaBarang[100];
int hargaTotal[100], sebelumBonus[100], setelahBonus[100];
float bonus[100];
string username[100];
string password[100];

main()
{
    int pil;
    bool ulang = 1;
    bool menu = 0;

    while (ulang)
    {
        system("cls");
        cout << "Banyak User : " << banyak_user << endl;
        cout << "[1] Login" << endl;
        cout << "[2] Daftar" << endl;
        cout << "Masukkan Pilihan : ";
        cin >> pil;
        switch (pil)
        {
        case 1:
            if (banyak_user == 0)
            {
                cout << "Login Dulu Bang";
                getch();
            }
            else
            {
                bool berhasil = 0;
                login(berhasil, ulang);
                if (berhasil == 1)
                {
                    ulang = 0;
                    menu = 1;
                }
            }
            break;
        case 2:
            daftar();
            break;
        }
    }

    while (menu)
    {
        system("cls");
        int pilMenu;

        cout << "[1] Pembelian" << endl;
        cout << "[2] Riwayat Pembelian" << endl;
        cout << "[3] Riwayat Pembelian sesuai nama" << endl;
        cout << "[4] Keluar" << endl;
        cout << "Pilihan : ";
        cin >> pilMenu;
        switch (pilMenu)
        {
        case 1:
            transaksi();
            break;
        case 2:
            if (banyak_pesanan == 0)
            {
                cout << "beli dulu bang";
                getch();
            }
            else
            {
                riwayat();
            }
            break;

        case 3 :
        if (banyak_pesanan == 0)
            {
                cout << "beli dulu bang";
                getch();
            }
            else
            {
                riwayatNama();
            }
            break;
        case 4:
            menu = 0;
            break;

        default:

            break;
        }
    }
}

void riwayatNama() {
    system("cls");
    string nami;
    int i,j;
    cout << "Masukkan Nama : ";
    cin >> nami;

    bool ada = 0;
    for ( i = 0 ; i < banyak_pesanan ; i++) {
        if (nama[i] == nami) {
            ada = 1;
            j = i;
        }
    }

    if (ada) {
        cout << "Nama : " << nama[j] << endl;
        cout << "Nama Barang : " << namaBarang[j] << endl;
        cout << "Harga Total : " << hargaTotal[j] << endl;
        cout << "Bonus : " << bonus[j] << endl;
        cout << "Harga Total Setelah Bonus : " << setelahBonus[j] << endl;
        getch();
    } else {
        cout << "Gak ada Ngab";

        getch();
    }
    

}


void riwayat()
{
    system("cls");
    for (int i = 0; i < banyak_pesanan; i++)
    {
        cout << endl;
        cout << endl;
        cout << "Nama : " << nama[i] << endl;
        cout << "Nama Barang : " << namaBarang[i] << endl;
        cout << "Harga Total : " << hargaTotal[i] << endl;
        cout << "Bonus : " << bonus[i] << endl;
        cout << "Harga Total Setelah Bonus : " << setelahBonus[i] << endl;
    }
    getch();
}

void transaksi()
{
    system("cls");
    string namatransaksi, namabarang;
    int kode, sebelumbonus;
    float bonis, jumlahbonus, jumlahBeli, harga;
    bool transaksikode = 1;
    int lanjut;

    while (transaksikode)
    {
        system("cls");
        cout << "Masukkan Nama Anda : ";
        cin >> namatransaksi;
        cout << endl;
        cout << "======================================" << endl;
        cout << " Kode Barang |  Nama Barang |  Harga  " << endl;
        cout << "======================================" << endl;
        cout << "    1241     |   Diamonds   | Rp.450  " << endl;
        cout << "    1242     |   UC         | Rp.510  " << endl;
        cout << "    1243     |   Primo Gem  | Rp.2300 " << endl;
        cout << "    1244     |   Robux      | Rp.1200 " << endl;
        cout << "======================================" << endl;
        cout << endl;
        cout << "Masukkan Kode Barang : ";
        cin >> kode;
        switch (kode)
        {
        case 1241:
            namabarang = "Diamonds";
            harga = 450;
            break;
        case 1242:
            namabarang = "UC";
            harga = 510;
            break;
        case 1243:
            namabarang = "Primo Gem";
            harga = 2300;
            break;
        case 1244:
            namabarang = "Robux";
            harga = 1200;
            break;
        default:
            break;
        }
        if (kode >= 1241 && kode <= 1244)
        {
            transaksikode = 0;
            cout << "Ingin Membeli Berapa : ";
            cin >> jumlahBeli;
            if (kode == 1241 || kode == 1242 && jumlahBeli > 100)
            {
                jumlahbonus = 0.1 * jumlahBeli;
                bonis = jumlahbonus * harga;
            }
            else if (kode == 1243 || kode == 1244 && jumlahBeli > 50)
            {
                jumlahbonus =  0.2 * jumlahBeli;
                bonis = jumlahbonus * harga;
            }
            cout << endl;
            cout << "Harga Total : " << jumlahBeli * harga << endl;
            cout << "Total Sebelum Bonus : " << jumlahBeli * harga << endl;
            cout << "Bonus : " << bonis << endl;
            cout << "Harga Setelah Bonus : " << jumlahBeli * harga - bonis << endl;
            nama[banyak_pesanan] = namatransaksi;
            namaBarang[banyak_pesanan] = namabarang;
            hargaTotal[banyak_pesanan] = jumlahBeli * harga;
            sebelumBonus[banyak_pesanan] = sebelumbonus;
            bonus[banyak_pesanan] = bonis;
            setelahBonus[banyak_pesanan] = jumlahBeli * harga - bonis;
            banyak_pesanan++;
            cout << endl;
            cout << "[1] Ya" << endl;
            cout << "[2] Tidak" << endl;
            cout << "Ingin Melanjutkan Transaksi : ";
            cin >> lanjut;
            if (lanjut == 1)
            {
                transaksikode = 1;
            }
            else
            {
                transaksikode = 0;
            }
        }
        else
        {
            transaksikode = 1;
        }
    }
}

void daftar()
{
    system("cls");
    string nama;
    string pass;

    cout << "Masukkan Username : ";
    cin.ignore();
    getline(cin, nama);
    cout << "Masukkan Password : ";
    getline(cin, pass);

    bool ada = 0;
    for (int i = 0; i < banyak_user; i++)
    {
        if (nama == username[i])
        {
            ada = 1;
        }
    }

    if (ada)
    {
        cout << "Username Sudah ada";
        getch();
    }
    else
    {
        username[banyak_user] = nama;
        password[banyak_user] = pass;
        banyak_user++;
    }
}

void login(bool &berhasil, bool &ulang)
{
    string nama;
    string pass;
    int ulangLog = 5;

    cin.ignore();
    while (ulangLog > 0)
    {
        system("cls");
        cout << "Masukkan Username : ";
        getline(cin, nama);
        cout << "Masukkan Password : ";
        getline(cin, pass);

        bool ada = 0;
        for (int j = 0; j < banyak_user; j++)
        {
            if (username[j] == nama && password[j] == pass)
            {
                ada = 1;
            }
        }

        if (ada)
        {
            cout << "Login Berhasil";
            berhasil = 1;
            ulang = 0;
            ulangLog = 0;
            getch();
        }
        else
        {
            ulangLog--;
            cout << "Batas salah adalah 5x Sisa Batas Salah " << ulangLog << "x";
            getch();
        }
        if (ulangLog == 0)
        {
            ulang = 0;
        }
    }
}