#include <iostream>
using namespace std;


string pesanmakanan[100][5];

void belimakanan(){
    string namamakanan;
    bool masuk = true;
    int a = 1;

    cin.ignore();
    cout << " 1. Nasi Goreng << 10.000   " << endl;
    cout << " 2. Mie Ayam << 8.000  " << endl;
    cout << " 3. Lotek << 9.000 " << endl;
    cout << " 4. Nasi Telur << 7.000 " << endl;
    cout << " 5. Indomie << 5.000 " << endl;
    cout << " Ingin Pesan Apa : ";
    cin >> namamakanan;
    getline(cin,namamakanan);
        for (int i = 0; i < a; i++){
        if (namamakanan == pesanmakanan[i][0]){
           cout << " Pesanan Telah di Terima Tolong Tunggu Sebentar " << endl;
           bool masuk = false;
          break;
        }

    }
        if (masuk) {
            pesanmakanan [a][0] = namamakanan;
            a++;
        }

}

void diantar(){
    string antar;
    bool dapat = false;
    int a = 1;

  
        for (int i = 0; i < a; i++){
        if (antar == pesanmakanan[i][0]){
           cout << " Pesanan yang di Antar" << endl;
           cout << " 1." << pesanmakanan[i][0] << endl;
           bool dapat = true;
          break;
        }

    }
        if (!dapat) {
           cout << " Pesanan Tidak ada di Daftar " << endl;
        }

}
   
        




int main (){
   int pilih ;
   char ulang;

   do {
    cout << " 1. Beli Makanan " << endl;
    cout << " 2. Di antar " << endl;
    cout << " Pilih Menu : ";
    cin >> pilih;

    switch (pilih){
        case 1:
        belimakanan();
        break;
        
        case 2:
        diantar();
        break;
    }
     cout << " Apakah anda ingin mengulang (y/t): ";
     cin >> ulang;
     
   } while ( ulang == 'y' || ulang == 'Y');
   return 0;

}