  cout << "Masukkan Nama Anda : ";
        cin.ignore();
        getline(cin, namatransaksi);