#include <iostream>
using namespace std;

int saldo, koin; 
string nama_koin[10] = {"$BTC", "$ETH", "$SOL"};  
int stok[10] = {1 ,4 ,0};
int main();

void nama_menu(){
cout << "=============/n";
cout << "Wallet Crypto/n";
cout << "=============/n";
}

void menu(){
    cout << "1. Isi Saldo" << endl;
    cout << "2. Beli Aset Crypto" << endl;
    cout << "3. Jual Aset Crypto" << endl;
    cout << "4. Portofolio Pengguna" << endl;
    cout << "5. Exit" << endl;
    cout << ">";
}

void isi_saldo(){
    cout << "/n/n";
    int  isi, total_saldo, stok;
    cout << "== ISI SALDO ==/n";
    cout << "/nSaldo Anda : "; cin >> saldo;
    cout << "/nIngin isi berapa saldo : "; cin >> isi;
    cout << "/nBerhasil isi saldo sebesar :";
}

void beli_aset(){
    cout << "/n/n";
    int beli_koin, jumlah_koin;
    cout << "== BELI ASET CRYPTO ===/n";
    cout << "1. $BTC - $ 533.34" << endl;
    cout << "2. $ETH - $ 302.45" << endl;
    cout << "3. $SOL - $ 251.04" << endl;

}

void jual_aset(){
    cout << "/n/n";
    int jual_koin, jumlah_jual;
    cout << "== JUAL ASET CRYPTO ==";
    cout << "1. $BTC - 1pcs" << endl;
    cout << "2. $ETH - 4pcs" << endl;
    cout << "3. $SOL - 0pcs" << endl;

}

void PORTOFOLIO(){
    int pembelian, penjualan;
    cout << "== PORTOFOLIO USER ==/n";
    cout << "total yang dimiliki";
    cout << "1. $BTC - 1 unit(s)" << endl;
    cout << "2. ETH -2 unit(s)" << endl;

}