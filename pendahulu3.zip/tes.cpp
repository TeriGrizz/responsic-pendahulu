#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

struct donorProfile {
    string name;   
    string gol;    
    int amount;   
};
string spaceToUnderscore(string str) {
    for (size_t i = 0; i < str.length(); i++) {
     if (str[i] == ' ') str[i] = '_';
     }
    return str;
}
string underscoreToSpace(string str) {
    for (size_t i = 0; i < str.length(); i++) {
     if (str[i] == '_') str[i] = ' ';
    }
    return str;
}
string toLowerCase(string str) {
    string result = "";
    for (size_t i = 0; i < str.length(); i++) {
     result += tolower(str[i]);
    }
    return result;
}
void loadData(donorProfile data[], int &datalen, const string &filename) {
    ifstream file("data.txt");
    datalen = 0;
    
    if (file.is_open()) {
        while (file >> data[datalen].name >> data[datalen].gol >> data[datalen].amount) {
        datalen++;
        }
     file.close();
    } else {
     ofstream newFile(filename);
     newFile.close();
    }
}
void appendToDataFile(donorProfile data[], int &datalen, const string &filename) {
    if (datalen >= 100) {
        cout << "Kapasitas data penuh!\n";
        return;
    }

    donorProfile newDonor;
    cout<<"\n=== TAMBAH DATA PENDONOR ===\n";
    cout<<"Nama Lengkap    : ";
    cin.ignore();
    getline(cin, newDonor.name);
    cout<<"Golongan Darah  : ";
    cin>>newDonor.gol;
    cout<<"Jumlah Donor(ml): ";
    cin>>newDonor.amount;
    ofstream file("data.txt", ios::app);
    if (file.is_open()) {
        file << spaceToUnderscore(newDonor.name) << " " << newDonor.gol << " " << newDonor.amount << "\n";
        file.close();
        data[datalen] = newDonor;
        datalen++;
        cout<<"Data berhasil disimpan!\n";
    } else {
        cout<<"Gagal membuka file penyimpanan.\n";
    }
}
void displayData(const donorProfile data[], int datalen) {
    if (datalen == 0) {
        cout << "Belum ada data pendonor.\n";
        return;
    }

    cout<< "=========================================================\n";
    cout<< left << setw(5) << "No" << setw(30) << "Nama Lengkap" << setw(10) << "Gol. Darah" << "Jumlah (ml)\n";
    cout<< "=========================================================\n";
    for (int i = 0; i < datalen; i++) {
        cout << left << setw(5) << (i + 1) 
             << setw(30) << underscoreToSpace(data[i].name) 
             << setw(10) << data[i].gol 
             << data[i].amount << " ml\n";
    }
    cout << "=========================================================\n";
}
void sortingData(donorProfile data[], int datalen) {
    if (datalen <= 1) {
        cout << "Data terlalu sedikit untuk diurutkan.\n";
        return;
    }
    int pilihsorting, arahsorting;
    cout<<"\n--- MENU SORTING ---\n";
    cout<< "Urutkan berdasarkan: \n";
    cout<<"1.nama lengakp\n";
    cout<<"2.golongan darah\n";
    cout<<"3.jumlah donor\n";
    cout<<"pilih [1-3];";
    cin>>pilihsorting;
    
    cout<<"Arah pengurutan:  ";
    cout<<"1.terkecil ke terbesar\n";
    cout<<"2.terbesar ke terkecil\n";
    cout<<"pilih tipe [1-2]:";
    cin >> arahsorting;
    for (int i = 0; i < datalen - 1; i++) {
        for (int j = 0; j < datalen - i - 1; j++) {
            bool ganti = false;
            if (pilihsorting == 1) { 
                if (arahsorting == 1) ganti = (toLowerCase(data[j].name) > toLowerCase(data[j+1].name));
                else ganti= (toLowerCase(data[j].name) < toLowerCase(data[j+1].name));
            } 
            else if (pilihsorting == 2) { 
                if (arahsorting == 1) ganti = (data[j].gol > data[j+1].gol);
                else ganti = (data[j].gol < data[j+1].gol);
            } 
            else if (pilihsorting == 3) { 
                if (arahsorting == 1) ganti = (data[j].amount > data[j+1].amount);
                else ganti = (data[j].amount < data[j+1].amount);
            }
            if (ganti) {
                donorProfile temp = data[j];
                data[j] = data[j+1];
                data[j+1] = temp;
            }
        }
    }
    cout << "Data berhasil diurutkan!\n";
    displayData(data, datalen);
}
void searchingData(const donorProfile data[], int datalen) {
	string keyword;
    if (datalen == 0) {
        cout << "\nTidak ada data untuk dicari.\n";
        return;
    }

    int pilih;
    cout<<"--- MENU PENCARIAN ---\n";
    cout<<"Cari berdasarkan:  \n";
    cout<<"1.nama \n";
    cout<<"2.golongan darah pilihan\n";
    cout<<"pilih [1-2]:";
    cin >>pilih;

    cout << "Masukkan kata kunci pencarian: ";
    cin.ignore();
    getline(cin, keyword);
    keyword = toLowerCase(keyword);

    bool found = false;
    cout <<"\n=== HASIL PENCARIAN ===\n";
    cout <<left<<setw(5)<< "No" << setw(30) << "Nama Lengkap" << setw(10) << "Gol. Darah" << "Jumlah (ml)\n";
    cout <<"=========================================================\n";

    for (int i = 0; i < datalen; i++) {
        string target = "";
        if(pilih == 1) target = toLowerCase(underscoreToSpace(data[i].name));
        else target = toLowerCase(data[i].gol);
        if (target.find(keyword) != string::npos) {
            cout << left << setw(5) << (i + 1) 
               << setw(30) << underscoreToSpace(data[i].name) 
               << setw(10) << data[i].gol 
               << data[i].amount << " ml\n";
            found = true;
        }
    }
    if (!found) {
        cout << "Data tidak ditemukan.\n";
    }
    cout << "=========================================================\n";
}
int main() {
    const int max = 100;
    donorProfile data[max]; 
    int datalen = 0;                 
    string filename = "data.txt";    
    loadData(data, datalen, "data.txt");
    int menu;
    char pilih;
    do {
        cout << "==================================\n";
        cout << "   VAMPIRE: BLOOD FARM PROJECT    \n";
        cout << "==================================\n";
        cout << "1. Tampilkan Semua Data\n";
        cout << "2. Tambah Data Baru\n";
        cout << "3. Urutkan Data \n";
        cout << "4. Cari Data \n";
        cout << "5. Keluar\n";
        cout << "Pilih Menu (1-5): ";
        cin >> menu;
        switch(menu) {
            case 1:
                displayData(data, datalen);
            break;
            case 2:
                appendToDataFile(data, datalen, "data.txt");
            break;
            case 3:
                sortingData(data, datalen);
            break;
            case 4:
                searchingData(data, datalen);
            break;
            case 5:
                cout << "\nTerima kasih! Program selesai.\n";
            break;
            default:
                cout << "\nPilihan menu tidak valid!\n";
        }
        cout<<"kembali ke menu utama?[y/n]:";
        cin>>pilih;
        system("pause");
        system("cls");
    } while(pilih == 'y' || pilih == 'Y');

    return 0;
}

