#include <iostream>
using namespace std;

const int jumlahJenis = 2;
string jenisCucian[jumlahJenis] = {"Reguler", "Kilat"};
char jeniscuci[jumlahJenis] = {'a','b'};
int jumlahPesanan = 0;

string nama[100];
int noPesanan[100];
double cucian;

void lihatnama() {
	cout << "\nRiwayat Pesanan\n";
	if (jumlahPesanan == 0){
		cout << "Belum Ada Transaksi\n";
		}
	for (int i = 0; i < jumlahPesanan; i++){
		cout << "Pesanan Ke-"<< i+1 << endl;
		cout << "Nama: " << nama[i] << endl;
		cout << "No Pesanan: " << noPesanan[i] << endl;
		}
		
	}
bool loginadmin (){
	int percobaan = 0;
	string user, pass;
	cout << "\n===Login Admin===\n";
	cout << "Username: "; cin >> user;
	cout << "Password: "; cin >> pass;
	if (user == "admin" && pass == "admin"){
	cout << "\nLogin Berhasil\n"; return true;
		}
	percobaan++;
	cout << "\nLogin Gagal\n"; return false;
	}
void menuinput(){
	if (!loginadmin()) {
		cin.ignore(); 
		system("pause");
		cin.get();
		}

	cout << "Masukan Nama Pelanggan: "; cin >> nama[jumlahPesanan];
	cout << "Masukan Nomor Pesanan: "; cin >> noPesanan[jumlahPesanan];
	cout << "Pilih Jenis Layanan\n";
	cout << "a. Reguler\n";
	cout << "b. Kilat\n";
	cout << "Pilih: "; cin >> jeniscuci;
	cout << "Berat Cucian (Kg): "; cin >> cucian;
	if (cucian < 0 || cucian > 50){
		cout << "\nInput Tidak Valid\n";
			}
	}
void menuUtama(){
	cout << "\n===MENU===\n";
	cout << "1. Lihat Pesanan Berdasarkan Nama\n";
	cout << "2. Lihat Pesanan Berdasarkan No Pesanan\n";
	cout << "3. Input Pelanggan\n";
	}
int main () {
	menuinput();
	int pilihan;
	char kembali;
	do {
	menuUtama();
	cout << "Pilih Menu: "; cin >> pilihan;
	switch(pilihan){
		case 1: lihatnama();
		break;
		
		}
	
	cout << "\nApakah Anda Ingin Kembali? (y/n): "; cin >> kembali;
	} while (kembali != 'y' || kembali != 'Y');
}
